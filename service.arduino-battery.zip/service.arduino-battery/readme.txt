============
Installation
============

1. Pack this folder to .zip file
2. Copy your .zip to libreelec shared folder
2. Launch Kodi >> Add-ons >> Get More >> .. >> Install from zip file (schoose your addon .zip file)
3. Enjoy!
